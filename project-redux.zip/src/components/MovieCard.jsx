import React from "react";

const MovieCard = () => {
  return <div>MovieCard</div>;
};

export default MovieCard;
